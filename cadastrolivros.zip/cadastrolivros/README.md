#IMPLEMENTAÇÃO

Olá

A implementação foi feita da seguinte forma:

Criação do banco de dados, como não tenho familiaridade com Laravel, tive muito problemas em roda a tela de cadastro,
por problemas na aplicação e a forma que utilizei, mas vamos caminhando e corrigindo.

Bom eu refiz o arquivo de BD do material de apoio para bater com o que criei no MySQL, caso o laravel não crie um arquivo com essas informações.

Toda a função que a segunda página deve executar está em LivroController (usei o Android Studio Code e Sublime)

Utilizei o WAMP, porém tive muito problema em rodar a aplicação por problemas na intalação, por conta do uso desse framework,
consegui rodar ele em outra máquina, mas não me atentei tanto ao visual, meu intuito era fazer rodar, porém como a avaliação vai ser do código em si, estou encaminhando o que desenvolvi.
