-- -------------------------------------------------
-- Tabela de usuários
-- -------------------------------------------------

CREATE TABLE `usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
  
  )
  ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO usuarios (id,nome) VALUES 
(1,'Rafael'),
(2,'Marcia'),
(3,'Edgar'),
(4,'Jessica'),
(5,'William');

---------------
-- Tabela de livros
-- -------------------------------------------------

CREATE TABLE `livros` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL,
  `usuario_id` int(10) unsigned NOT NULL,
  `quantity` 
  `price`

  PRIMARY KEY (`id`),
  KEY `pedidos_FK_1` (`usuario_id`),
  CONSTRAINT `pedidos_FK` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) 
  )
  
  ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO livros
(id, description,usuario_id)
VALUES 
(1,'Um Conto de Duas Cidades',1,1,1),
(2,'O Leão, A Feiticeira e o Guarda-Roupa',1,2,2),
(3,'Código da Vinci',2,3,3),
(4,'O Alquimista',3,2,2);


