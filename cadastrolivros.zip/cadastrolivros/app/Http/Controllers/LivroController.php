<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Livro;

class LivroController extends Controller
{
    public function index() {
        $product = Livro::all();
        $total = Livro::all()->count();
        return view ('list.livros', compact('product', 'total'));
    
    }

    public function create () {
        return view ('include.livro');
    }

    public function store(Request $request) {
        $product = new Livro;
        $product->name = $request->name;
        $product->description = $request->description;
        $product->quantity = $request->quantity;
        $product->save();
        return redirect()->route('product.index')->with('message', 'Livro cadastrado com sucesso');
    
    }

    public function show($id){ 
        //
    }

    public function edit($id){
        $product = Livro::findOrFail($id);
        return view('alter.livro', compact('product'));
    }


    public function update(Request $request, $id) {
        $product = Livro::findOrFail($id);
        $product->name = $request->name;
        $product->description = $request->description;
        $product->quantity = $request->quantity;
        $product->save();
        return redirect()->route('product.index')->with('message', ' Informações alteradas com sucesso');
    
    }
    public function destroy($id){
        $product = Livro::findOrFail($id);
        $product->delete();
        return redirect()->route('product.index')->with('message', 'Livro excluído com sucesso');
}
    }