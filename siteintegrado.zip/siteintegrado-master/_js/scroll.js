//cabecalho nav
$(document).on("scroll", function() {
    var scrollTop = $(document).scrollTop();
    if (scrollTop > 20) {
        $('.navbar').addClass('active');
    } else {
        $('.navbar').removeClass('active');
    }
});

